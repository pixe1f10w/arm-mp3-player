#ifndef _FONT_CLOCK_H_
#define _FONT_CLOCK_H_


//----- DEFINES -----
#define FONT3_START                    (0x30)
#define FONT3_WIDTH                    (16)
#define FONT3_HEIGHT                   (20)


//----- GLOBALS -----
extern const unsigned char font3[];


#endif //_FONT_CLOCK_H_
