#ifndef _IMG_H_
#define _IMG_H_


//----- GLOBALS -----
extern const unsigned char img_station[3][4*32];
extern const unsigned char img_share[3][4*32];
extern const unsigned char img_card[3][4*32];
extern const unsigned char img_clock[3][4*32];
extern const unsigned char img_settings[3][4*32];
extern const unsigned char img_back[3][4*32];
extern const unsigned char img_power[3][4*32];


#endif //_IMG_H_
