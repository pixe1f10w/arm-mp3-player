#ifndef _FONT_8X8_H_
#define _FONT_8X8_H_


//----- DEFINES -----
#define FONT1_START                    (0x20)
#define FONT1_WIDTH                    (8)
#define FONT1_HEIGHT                   (8)


//----- GLOBALS -----
extern const unsigned char font1[];


#endif //_FONT_8X8_H_
