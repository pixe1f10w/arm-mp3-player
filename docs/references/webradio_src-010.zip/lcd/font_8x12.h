#ifndef _FONT_8X12_H_
#define _FONT_8X12_H_


//----- DEFINES -----
#define FONT2_START                    (0x20)
#define FONT2_WIDTH                    (8)
#define FONT2_HEIGHT                   (12)


//----- GLOBALS -----
extern const unsigned char font2[];


#endif //_FONT_8X12_H_
