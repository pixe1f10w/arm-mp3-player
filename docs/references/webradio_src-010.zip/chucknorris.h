#ifndef _CHUCKNORRIS_H_
#define _CHUCKNORRIS_H_


//----- DEFINES -----
#define CHUCKNORRIS_FILE                   "CHUCKNORRIS.INI"


//----- PROTOTYPES -----
void chucknorris_rfact(void);
void chucknorris_fact(unsigned int nr);


#endif //_CHUCKNORRIS_H_
