This directory contains third party software packages that are used by the
WebRadio. Each package has its own copyright and license agreement, and it is
your responsibility to comply with the terms of those agreements.
